//
//  ViewReportViewController.swift
//  Agrecom_Personal
//
//

import UIKit
import Foundation
import Firebase

class ViewReportViewController: UIViewController {
    
    
    @IBOutlet weak var customerNameLabel: UILabel!
    
    @IBOutlet weak var serviceDateLabel: UILabel!
    
    @IBOutlet weak var vegLevelLabel: UILabel!
    
    @IBOutlet weak var correctiveRecLabel: UILabel!
    
    @IBOutlet weak var actionPlanLabel: UILabel!
    
    // Create reference to Firebase user and to Firebase DB
    let user = Firebase.Auth.auth().currentUser;
    let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        displayElements()
        
    }
    
    func displayElements() {
        
        if user != nil {
            
            // User is signed in
            let userID = user?.uid
            let docRef = db.collection("users").document(userID!).collection("report").document("userReportDoc")// old line
            
            // "report_john_01-01-21"
            
            // Get reference path to document, based on customer name and service date
            
            // Get User's vegLevel, correctiveRec, and actionPlan
            docRef.getDocument { (document, error) in
                
                guard let document = document, document.exists else {return}
                let myData = document.data()
                let userCustomerName = myData?["customerName"] as? String ?? ""
                let userServiceDate = myData?["serviceDate"] as? Date ?? Date()
                let userVegLevel = myData?["vegLevel"] as? String ?? ""
                let userCorrectiveRec = myData?["correctiveRec"] as? String ?? ""
                let userActionPlan = myData?["actionPlan"] as? String ?? ""
                
                let dateFormatter = DateFormatter() // Formats the date
                dateFormatter.dateFormat = "MM/dd/YY"
                let userServiceDateString = dateFormatter.string(from: userServiceDate)
                
                self.serviceDateLabel.text = userServiceDateString
                self.customerNameLabel.text = userCustomerName
                self.vegLevelLabel.text = userVegLevel
                self.correctiveRecLabel.text = userCorrectiveRec
                self.actionPlanLabel.text = userActionPlan
                
            }// DB
            
            
        }
        else{
            
            // User is not signed in
            print("No one signed in")
            
        }// else
        
        
        
    }// displayElements
    
    

}
