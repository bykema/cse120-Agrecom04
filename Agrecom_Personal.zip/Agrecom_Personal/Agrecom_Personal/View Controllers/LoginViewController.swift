//
//  LoginViewController.swift
//  Agrecom_Personal
//
//

import UIKit
import Firebase

class LoginViewController: UIViewController {
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        setUpElements()
        
    }
    
    func setUpElements(){
        
        // Initially, error label is not visible
        errorLabel.alpha = 0;
        
    }
    
    // Check text fields and validate data is correct
    //  If it is correct, return nil
    //  Otherwise, return error message (String)
    func validateFields() -> String? {
            
        // Check all fields filled in (Non-empty)
        if emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
            
            return "Please fill in all fields."
                
        }// if
            
        return nil
            
    }// validateFields

    

    @IBAction func loginTapped(_ sender: Any) {
        
        // Validate text fields
        let error = validateFields()
                
        if error != nil {
                    
            showError(error!)
                    
        }// if
        else {
                    
            // Create cleaned version of data
            let email = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            let password = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
                    
            // Signing in the user
            Auth.auth().signIn(withEmail: email, password: password) {
                    (result, error) in
                        
                if error != nil {
                // Couldn't sign in - Show error message
                    self.errorLabel.text = error!.localizedDescription
                    self.errorLabel.alpha = 1
                }// if
                else {
                    self.transitionToHome()
                }// else
            }//
                    
        }// else
        
    }// loginTapped
    
    func showError (_ message:String) {
        // There was something wrong. Show error message
        errorLabel.text = message
        errorLabel.alpha = 1
    }// showError
    
    
    func transitionToHome() {
            
        let homeViewController = storyboard?.instantiateViewController(identifier: Constants.Storyboard.homeViewController) as? HomeViewController
            
        view.window?.rootViewController = homeViewController
        view.window?.makeKeyAndVisible()
            
    }// transitionToHome
    

}
