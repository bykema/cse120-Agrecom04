//
//  CreateReportViewController.swift
//  Agrecom_Personal
//
//

import UIKit
import Foundation
import Firebase

class CreateReportViewController: UIViewController {
    
    @IBOutlet weak var customerNameTextField: UITextField!
    
    @IBOutlet weak var serviceDatePicker: UIDatePicker!
    
    @IBOutlet weak var vegLevelTextField: UITextField!
    
    @IBOutlet weak var correctiveRecTextField: UITextField!
    
    @IBOutlet weak var actionPlanTextField: UITextField!
    
    
    // Create reference to Firebase user and to Firebase DB
    let user = Firebase.Auth.auth().currentUser;
    let db = Firestore.firestore()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        
    }//
    
    
   
    
    @IBAction func updateTapped(_ sender: Any) {
        
        // Validate fields
        
        // Process / Clean Data
        let customerName = customerNameTextField.text!
        let vegLevel = vegLevelTextField.text!
        let correctiveRec = correctiveRecTextField.text!
        let actionPlan = actionPlanTextField.text!
        let serviceDate = serviceDatePicker.date
        
        // Store into DB
        if user != nil {
            
            // Create a reference path to "report" subcollection
            let userID = user?.uid
            let docRef = db.collection("users").document(userID!).collection("report")
            
            let dateFormatter = DateFormatter() // Formats the date
            dateFormatter.dateFormat = "MM-dd-YY"
            let serviceDateString = dateFormatter.string(from: serviceDatePicker.date)
            
            // Add "report" document to the subcollection
            // Unique report ID: "report_" + customer name + service date i.e. "report_martin_01/01/21"
            let customerReport = "report_" + customerNameTextField.text!
                .replacingOccurrences(of: " ", with: "")         // Removes spaces between
                .trimmingCharacters(in: .whitespacesAndNewlines) // Removes spaces and /n, at end
                .lowercased()                                    // Makes string lowercase
                + "_" + serviceDateString
            
            docRef.document(customerReport).setData([
                "customerName": customerName,
                "serviceDate": serviceDate,
                "vegLevel" : vegLevel,
                "correctiveRec": correctiveRec,
                "actionPlan": actionPlan
            ]) { err in
                if let err = err {
                    print("Error writing document: \(err)")
                } else {
                    print("Document successfully written!")
                }
                
            }// DB
            
            
        }// user != nil
        
    }// updateTapped
    
    

}
