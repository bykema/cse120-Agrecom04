//
//  SignUpViewController.swift
//  Agrecom_Personal
//
//

import UIKit
import Firebase

class SignUpViewController: UIViewController {
    
    
    @IBOutlet weak var firstNameTextField: UITextField!
    
    @IBOutlet weak var lastNameTextField: UITextField!
    
    @IBOutlet weak var emailTextField: UITextField!
    
    @IBOutlet weak var passwordTextField: UITextField!
    
    @IBOutlet weak var errorLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        setUpElements()
        
    }
    
    func setUpElements(){
        
        // Initially, error label is not visible
        errorLabel.alpha = 0;
        
    }// setUpElements
    
    func isPasswordValid(_ password : String) -> Bool {
        
        
        // At least 8 characters
        // Includes number
        // Includes special character
        let passwordTest = NSPredicate(format: "SELF MATCHES %@", "^(?=.*[a-z])(?=.*[$@$#!%*?&])[A-Za-z\\d$@$#!%*?&]{8,}")
        
        return passwordTest.evaluate(with: password)
        
    }// isPasswordValid
    
    // Check text fields and validate data is correct
    //  If it is correct, return nil
    //  Otherwise, return error message (String)
    func validateFields() -> String? {
            
        // Check all fields filled in (Non-empty)
        if firstNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            lastNameTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            emailTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" ||
            passwordTextField.text?.trimmingCharacters(in: .whitespacesAndNewlines) == "" {
                
                return "Please fill in all fields."
                
        }// if
            
        // Check password is secure
        let cleanedPassword = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        if isPasswordValid(cleanedPassword) == false {
            // Password wasn't secure enough
            return "Please make sure password contains at least 8 characters, a special character, and a number."
                
        }// if
            
        // Return nil if no error
        return nil
            
    }// validateFields
    

    
    @IBAction func signUpTapped(_ sender: Any) {
        
        // Validate Text Fields
        let error = validateFields()
                
        if error != nil {
                    
            showError(error!)
                    
        }// if
        else {
                    
        // Create cleaned version of data
        let firstName = firstNameTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let lastName = lastNameTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let email = emailTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
        let password = passwordTextField.text!.trimmingCharacters(in: .whitespacesAndNewlines)
            
        
                    
        // Create User (Also signs them in)
        Auth.auth().createUser(withEmail: email, password: password) { (result, err) in
                        
            // Check for errors
            if err != nil {
            // There was an error creating a user
                self.showError("Error creating user")
                            
            }// if
            else {
                // Creating user was sucsessful, store in DB
                let db = Firestore.firestore()
                
                db.collection("users").document(result!.user.uid).setData([
                    "firstname":firstName,
                    "lastname": lastName,
                    "email":email
                ]) { err in
                    if let err = err {
                        print("Error writing document: \(err)")
                    } else {
                        print("Document successfully written!")
                    }
                    
                }
                
                /*
                db.collection("users").addDocument(data: ["firstname":firstName, "lastname": lastName, "email":email, "uid": result!.user.uid]) { (error) in
                                
                        if error != nil {
                        // Show error message
                            self.showError("Error saving user data")
                        }// if
                                
                }//
                */
                            
                // Transition to Home Screen
                self.transitionToHome()
                            
                            
                        }// else
                    }//
            }// else
    }// signUpTapped
    
    func showError (_ message:String) {
        // There was something wrong. Show error message
        errorLabel.text = message
        errorLabel.alpha = 1
    }// showError
        
    func transitionToHome() {
            
        let homeViewController = storyboard?.instantiateViewController(identifier: Constants.Storyboard.homeViewController) as? HomeViewController
            
        view.window?.rootViewController = homeViewController
        view.window?.makeKeyAndVisible()
            
    }// transitionToHome
    

}
