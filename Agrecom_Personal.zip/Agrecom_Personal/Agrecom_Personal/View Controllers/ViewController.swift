//
//  ViewController.swift
//  Agrecom_Personal
//
//

import UIKit

class ViewController: UIViewController {
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
    }
    
    
    
    @IBAction func signUpTapped(_ sender: Any) {
        
        
        
    }
    
    
    @IBAction func loginTapped(_ sender: Any) {
        
        
        
    }
    
    
    


}

