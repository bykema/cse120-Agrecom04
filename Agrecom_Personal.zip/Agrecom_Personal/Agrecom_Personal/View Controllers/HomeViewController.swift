//
//  HomeViewController.swift
//  Agrecom_Personal
//
//

import UIKit
import Firebase

class HomeViewController: UIViewController {
    
    @IBOutlet weak var greetingsLabel: UILabel!
    
    // Create reference to Firebase user and to Firebase DB
    let user = Firebase.Auth.auth().currentUser;
    let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        greetUser()
        
    }
    
    
    @IBAction func logOutTapped(_ sender: Any) {
        
        // Notify (Confirm logging out)
        
        // Sign out
        do {
            try Auth.auth().signOut()
        }
        catch {
            print("Unable to sign out user")
        }
        
        // Back to first screen
        transitionToFirst()
    }
    
    
    
    // Greet the currently logged in user
    func greetUser(){
        
        if user != nil {
            
            // User is signed in
            let userID = user?.uid
            let docRef = db.collection("users").document(userID!)
            
            // Get User's first and last name
            docRef.getDocument { (document, error) in
                
                guard let document = document, document.exists else {return}
                let myData = document.data()
                let userFirstName = myData?["firstname"] as? String ?? ""
                let userLastName = myData?["lastname"] as? String ?? ""
                
                self.greetingsLabel.text = "Welcome Back, "  + userFirstName + " " + userLastName + "!"
                
            }// DB
            
            
        }
        else{
            
            // User is not signed in
            print("No one signed in")
            
        }// else
        
    }// greetUser
    
    func transitionToFirst() {
            
        let firstViewController = storyboard?.instantiateViewController(identifier: Constants.Storyboard.firstViewController) as? ViewController
            
        view.window?.rootViewController = firstViewController
        view.window?.makeKeyAndVisible()
        
        print("Moving back to First Screen")
            
    }// transitionToHome
    
    
    

}
