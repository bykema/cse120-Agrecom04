
import Foundation

struct Constants {
    
    struct Storyboard {
        
        static let homeViewController = "HomeVC"
        static let firstViewController = "FirstVC"
    }
}
