//
//  TableViewController.swift
//  Flash Chat iOS13
//
//  Created by Hubert Le on 5/5/21.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import UIKit

final class Todo {
    let title: String
    let date: Date
    var isImportant: Bool
    var isFinished: Bool
    
    init(title: String) {
        self.title = title
        self.date = Date()
        self.isImportant = false
        self.isFinished = false
    }
}

class TableViewController: UITableViewController {

    var todos = [Todo]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        todos.append(Todo(title: "BaitStationReport1"))
    }
    
    // Mark: - Table view delegate
    override func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let delete = deleteAction(at: indexPath)
        return UISwipeActionsConfiguration(actions: [delete])
    }
    
    func deleteAction(at indexPath: IndexPath) -> UIContextualAction {
        let action = UIContextualAction(style: .destructive, title: "Delete") { (action, view, completion) in
            self.todos.remove(at: indexPath.row)
            self.tableView.deleteRows(at: [indexPath], with: .automatic)
        }
        action.image = UIImage(named: "Trash")
        action.backgroundColor = .red
        
        return action
    }
    

    // MARK: - Table view data source

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return todos.count
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "TodoCell", for: indexPath)

        // Configure the cell...
        let todo = todos[indexPath.row]
        cell.textLabel?.text = todo.title
        cell.detailTextLabel?.text = todo.date.description

        return cell
    }
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "seguee1", sender: self)
    }
}

