//
//  ViewReportController.swift
//  Flash Chat iOS13
//
//  Created by Hubert Le on 4/19/21.
//  Copyright © 2021 Angela Yu. All rights reserved.
//

import Foundation
import FirebaseDatabase

class ViewReportController: UIViewController, UIPickerViewDelegate, UIPickerViewDataSource, UITextFieldDelegate {
    
    private let db = Database.database().reference()
    @IBOutlet weak var button: UIButton!
    
    @IBOutlet weak var dateText: UITextField!
    let datePicker = UIDatePicker()
    @IBOutlet weak var vegeStatus: UITextField!
    @IBOutlet weak var stationUsed: UITextField!
    @IBOutlet weak var nameReport: UITextField!
    @IBOutlet weak var recommend: UITextField!
    @IBOutlet weak var inaccessable: UITextField!
    @IBOutlet weak var damageStation: UITextField!
    @IBOutlet weak var newBarcode: UITextField!
    @IBOutlet weak var typeStation: UITextField!
    @IBOutlet weak var baitStation: UITextField!
    
    

    let vegetation = ["LOW","MED","HIGH","NONE"]
    let station = ["Snap Traps", "Fly Station", "Squirrel Stations", "Liquid Bait Stations", "Double Trouble", "Mechanical Traps","Nait Boxes", "Other"]
    let type = ["Rodent", "Insect", "Reptile", "other"]
    let bait = ["Jaguar","Hawk", "Liqua Tox", "Tempo SC Ultra", "Terad", "Final", "Other"]
    
    var pickerView1 = UIPickerView()
    var pickerView2 = UIPickerView()
    var pickerView3 = UIPickerView()
    var pickerView4 = UIPickerView()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        createDatePicker()
        pickerView1.delegate = self
        pickerView1.dataSource = self
        
        pickerView2.delegate = self
        pickerView2.dataSource = self
        
        pickerView3.delegate = self
        pickerView3.delegate = self
        
        pickerView4.delegate = self
        pickerView4.delegate = self
        
        vegeStatus.inputView = pickerView1
        vegeStatus.textAlignment = .center
        vegeStatus.placeholder = "SELECT CONDITION"
        button.addTarget(self, action: #selector(addNewEntry), for: .touchUpInside)
        
        stationUsed.inputView = pickerView2
        stationUsed.textAlignment = .center
        stationUsed.placeholder = "SELECT STATION"
        button.addTarget(self, action: #selector(addNewEntry), for: .touchUpInside)
        
        typeStation.inputView = pickerView3
        typeStation.textAlignment = .center
        typeStation.placeholder = "SELECT TYPE"
        button.addTarget(self, action: #selector(addNewEntry), for: .touchUpInside)
        
        baitStation.inputView = pickerView4
        baitStation.textAlignment = .center
        baitStation.placeholder = "SELECT BAIT"
        button.addTarget(self, action: #selector(addNewEntry), for: .touchUpInside)
        
    }
    
    
//MARK: - Date Picker functions
    func createDatePicker() {
        let toolbar = UIToolbar()
        toolbar.sizeToFit()
        
        let doneBtn = UIBarButtonItem(barButtonSystemItem: .done, target: nil, action: #selector(donePressed))
        toolbar.setItems([doneBtn], animated: true)
        
        dateText.inputAccessoryView = toolbar
        
        dateText.inputView = datePicker
        
        datePicker.datePickerMode = .dateAndTime
}
    @objc func donePressed() {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        
        dateText.text = formatter.string(from: datePicker.date)
        self.view.endEditing(true)
    }
    
//MARK: - Vegetation Status functions
    public func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    public func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        if pickerView == pickerView1 {
            return vegetation.count
        } else if pickerView == pickerView2 {
            return station.count
        } else if pickerView == pickerView3 {
            return type.count
        } else if pickerView == pickerView4 {
            return bait.count
        }
        return 1
    }
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        if pickerView == pickerView1 {
            return vegetation[row]
        } else if pickerView == pickerView2 {
            return station[row]
        } else if pickerView == pickerView3 {
            return type[row]
        } else if pickerView == pickerView4 {
            return bait[row]
        }
        return ""
    }
    func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        if pickerView == pickerView1 {
            vegeStatus.text = vegetation[row]
            vegeStatus.resignFirstResponder()
        } else if pickerView == pickerView2 {
            stationUsed.text = station[row]
            stationUsed.resignFirstResponder()
        } else if pickerView == pickerView3 {
            typeStation.text = type[row]
            typeStation.resignFirstResponder()
        } else if pickerView == pickerView4 {
            baitStation.text = bait[row]
            baitStation.resignFirstResponder()
        }
    }
    

    
    @objc private func addNewEntry() {
        let object: [String: Any] = [
            "Date": dateText.text as Any,
            "Vegetation Status": vegeStatus.text as Any,
            "Recommendation": recommend.text as Any,
            "Station Used": stationUsed.text as Any,
            "Type of Activity": typeStation.text as Any,
            "Inaccessable": inaccessable.text as Any,
            "Damage Station": damageStation.text as Any,
            "New Barcodes": newBarcode.text as Any,
            "Bait Used": baitStation.text as Any
        ]
        db.child(nameReport.text ?? "").setValue(object)
    }

}
