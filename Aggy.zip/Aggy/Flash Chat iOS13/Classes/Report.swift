//
//
//

import Foundation
import Firebase

class Report{
    
    var timeIn:Date
    var timeOut:Date
    var serviceDate:Date
    var vegLevel:String
    var correctRec:String
    var actionPlan:String
    
    init(){
        
        timeIn = Date()
        timeOut = Date()
        serviceDate = Date()
        vegLevel = ""
        correctRec = ""
        actionPlan = ""
        
    }
    
    func addReportToDB() {
        
        // Create a reference to Firestore DB
        let db = Firestore.firestore()
        
        // Add to DB
        db.collection("reports").addDocument(data:
                                                ["timeIn": timeIn,
                                                 "timeOut": timeOut,
                                                 "serviceDate": serviceDate,
                                                 "vegLevel": vegLevel,
                                                 "correctRec": correctRec,
                                                 "actionPlan": actionPlan])
        { (error) in
            
            if error != nil {
            // Show error message
                print(error!)
            }// if
            
        }//
        
    }
    
    
    
}


