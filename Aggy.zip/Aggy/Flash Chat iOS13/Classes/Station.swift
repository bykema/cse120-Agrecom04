//
//
//

import Foundation
import Firebase

class Station{
    
    var stationType:String
    var activityPresent:Bool
    var chemicalType:String
    var chemAmount:Int
    var inaccessable:Bool
    var inaccessReason:String
    var damaged:Bool
    var damageReason:String
    
    init(){
        
        stationType = ""
        activityPresent = false
        chemicalType = ""
        chemAmount = 0
        inaccessable = false
        inaccessReason = ""
        damaged = false
        damageReason = ""
        
    }
    
    func addStationToDB() {
        
        // Create a reference to Firestore DB
        let db = Firestore.firestore()
        
        // Add to DB
        db.collection("stations").addDocument(data:
                                                ["stationType": stationType,
                                                 "activityPresent": activityPresent,
                                                 "chemicalType": chemicalType,
                                                 "chemAmount": chemAmount,
                                                 "inaccessable": inaccessable,
                                                 "inaccessReason": inaccessReason,
                                                 "damaged": damaged,
                                                 "damageReason": damageReason])
        { (error) in
            
            if error != nil {
            // Show error message
                print(error!)
            }// if
            
        }//
        
        
        
    }// addStationToDB
    
    
    
}


