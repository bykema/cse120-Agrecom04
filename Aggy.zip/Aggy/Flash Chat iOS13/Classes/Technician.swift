//
//
//

import Foundation
import Firebase

class Technician{
    
    var firstName:String
    var lastName:String
    var email:String
    
    init(){
        
        firstName = ""
        lastName = ""
        email = ""
        
    }
    
    
    func addTechnicianToDB(){
        
        // Create a reference to Firestore DB
        let db = Firestore.firestore()
        
        // Add to DB
        db.collection("technicians").addDocument(data:
                                            ["firstname":firstName,
                                             "lastname": lastName,
                                             "email": email])
        { (error) in
                        
            if error != nil {
            // Show error message
                print(error!)
            }// if
                        
        }//
        
        
    }// addTechnicianToDB
    
    
    
}

